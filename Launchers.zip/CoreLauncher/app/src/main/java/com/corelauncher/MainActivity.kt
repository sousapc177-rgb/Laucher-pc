package com.corelauncher

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.TimeInterpolator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.ActivityOptions
import android.content.Intent
import android.content.pm.ResolveInfo
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.*
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.*
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.InputMethodManager
import android.widget.*
import java.io.File

class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private lateinit var bg: ImageView
    private lateinit var pager: Pager
    private lateinit var dots: LinearLayout
    private lateinit var dockV: LinearLayout
    private lateinit var arrow: TextView
    private lateinit var drawer: FrameLayout
    private lateinit var dSearch: EditText
    private lateinit var dGrid: GridLayout
    private lateinit var st: FrameLayout
    private lateinit var stBody: LinearLayout
    private lateinit var mainList: LinearLayout
    private lateinit var welcome: FrameLayout
    private lateinit var wBox: FrameLayout
    private var wallBmp: Bitmap? = null
    private var apps = listOf<ResolveInfo>()
    private val prefs by lazy { getSharedPreferences("core", MODE_PRIVATE) }
    private val iconCache = HashMap<String, Bitmap>()
    private val handler = Handler(Looper.getMainLooper())
    private var pendingPage: String? = null
    private var stPage = "main"
    private var wStep = 0
    private var homeDirty = false
    private val PICK = 7
    private val ACC = Color.parseColor("#3482FF")

    // ---------- preferências ----------
    private fun gi(k: String, d: Int) = prefs.getInt(k, d)
    private fun si(k: String, v: Int) = prefs.edit().putInt(k, v).apply()
    private fun gb(k: String, d: Boolean) = prefs.getBoolean(k, d)
    private val shape: Int get() = gi("shape", 0)
    private val mul: Float get() = when (gi("speed", 1)) { 0 -> 0.7f; 2 -> 1.5f; else -> 1f }

    // ---------- tema ----------
    private val dark: Boolean get() = when (gi("theme", 2)) {
        0 -> false
        1 -> true
        else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }
    private fun pick(l: String, d: String) = Color.parseColor(if (dark) d else l)
    private val BG: Int get() = pick("#F2F4F8", "#0E1014")
    private val CARD: Int get() = pick("#FFFFFF", "#1B1E25")
    private val TXT: Int get() = pick("#111318", "#F1F2F5")
    private val SUB: Int get() = pick("#7C8190", "#8E93A2")
    private val DIV: Int get() = pick("#E6E8EE", "#2A2E37")
    private val FIELD: Int get() = pick("#E9ECF2", "#262A33")
    private val PRESS: Int get() = pick("#E6E9F0", "#262A33")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun lp(w: Int, h: Int = WRAP_CONTENT, wt: Float = 0f) = LinearLayout.LayoutParams(w, h, wt)
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
    private fun statusH(): Int {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else dp(28)
    }

    private fun tv(t: String, sp: Float, c: Int = TXT, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = sp; setTextColor(c); if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun round(c: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply {
        setColor(c); cornerRadius = dp(r).toFloat(); if (stroke != 0) setStroke(dp(2), stroke)
    }

    private fun pressBg() = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_pressed), round(PRESS, 10))
        addState(intArrayOf(), ColorDrawable(Color.TRANSPARENT))
    }

    private fun watcher(f: (String) -> Unit) = object : TextWatcher {
        override fun afterTextChanged(s: Editable?) { f(s.toString()) }
        override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
    }

    // ---------- animações estilo iOS (mola) ----------
    private class Spring : android.view.animation.Interpolator {
        override fun getInterpolation(t: Float): Float =
            if (t >= 1f) 1f else (1.0 - Math.exp(-7.0 * t) * Math.cos(9.0 * t)).toFloat()
    }

    private fun anim(v: View, dur: Long, ip: TimeInterpolator, upd: (Float) -> Unit, end: (() -> Unit)? = null) {
        (v.tag as? ValueAnimator)?.cancel()
        if (!gb("anim", true)) { upd(1f); end?.invoke(); return }
        val a = ValueAnimator.ofFloat(0f, 1f).apply { duration = (dur * mul).toLong(); interpolator = ip }
        a.addUpdateListener { upd(it.animatedValue as Float) }
        a.addListener(object : AnimatorListenerAdapter() {
            var cancelled = false
            override fun onAnimationCancel(an: Animator) { cancelled = true }
            override fun onAnimationEnd(an: Animator) {
                v.setLayerType(View.LAYER_TYPE_NONE, null)
                if (!cancelled) end?.invoke()
            }
        })
        v.tag = a
        v.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        a.start()
    }

    private fun showFull(v: View) {
        v.visibility = View.VISIBLE; v.alpha = 0f
        anim(v, 480, Spring(), { f ->
            v.alpha = minOf(1f, f * 3f); v.translationY = (1f - f) * dp(40)
            v.scaleX = 0.96f + 0.04f * f; v.scaleY = 0.96f + 0.04f * f
        })
    }

    private fun hideFull(v: View, end: (() -> Unit)? = null) {
        if (v.visibility != View.VISIBLE) return
        anim(v, 220, AccelerateInterpolator(1.2f), { f -> v.alpha = 1f - f; v.translationY = f * dp(30) }, { v.visibility = View.GONE; end?.invoke() })
    }

    private fun showSheet(v: View) {
        val h = resources.displayMetrics.heightPixels
        v.visibility = View.VISIBLE; v.alpha = 1f; v.translationY = h.toFloat()
        anim(v, 400, DecelerateInterpolator(2.2f), { f -> v.translationY = (1f - f) * h })
    }

    private fun hideSheet(v: View) {
        if (v.visibility != View.VISIBLE) return
        val h = resources.displayMetrics.heightPixels
        anim(v, 260, AccelerateInterpolator(1.2f), { f -> v.translationY = f * h }, { v.visibility = View.GONE })
    }

    private fun pressFx(v: View) {
        v.setOnTouchListener { x, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN)
                x.animate().scaleX(0.88f).scaleY(0.88f).setDuration(100).setInterpolator(DecelerateInterpolator()).start()
            else if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL)
                x.animate().scaleX(1f).scaleY(1f).setDuration(420).setInterpolator(Spring()).start()
            false
        }
    }

    // ---------- pager (páginas da tela inicial) ----------
    inner class Pager : FrameLayout(this@MainActivity) {
        private var pages = listOf<View>()
        var idx = 0
        private var off = 0f
        private var downX = 0f
        private var downY = 0f
        private var mode = 0
        private var vt: VelocityTracker? = null
        private var va: ValueAnimator? = null
        private val slop = ViewConfiguration.get(this@MainActivity).scaledTouchSlop
        var onPage: (Int) -> Unit = {}
        var onSwipeUp: () -> Unit = {}
        var onLong: () -> Unit = {}
        private val longR = Runnable { if (mode == 0) { performHapticFeedback(HapticFeedbackConstants.LONG_PRESS); mode = 3; onLong() } }

        fun set(list: List<View>) {
            removeAllViews(); pages = list
            list.forEach { addView(it, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT)) }
            idx = idx.coerceIn(0, maxOf(0, list.size - 1)); off = 0f; place(); onPage(idx)
        }

        private fun place() { pages.forEachIndexed { i, v -> v.translationX = ((i - idx) * width).toFloat() + off } }

        override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { super.onSizeChanged(w, h, ow, oh); place() }

        fun go(i: Int) { animTo(i.coerceIn(0, maxOf(0, pages.size - 1))) }

        private fun animTo(n: Int) {
            va?.cancel()
            val start = off + ((n - idx) * width).toFloat()
            idx = n; off = start; place(); onPage(idx)
            val a = ValueAnimator.ofFloat(start, 0f)
            a.duration = (480 * mul).toLong(); a.interpolator = Spring()
            a.addUpdateListener { off = it.animatedValue as Float; place() }
            va = a; a.start()
        }

        private fun settle(vx: Float) {
            var n = idx
            if ((off < -width / 5f || vx < -900f) && idx < pages.size - 1) n++
            else if ((off > width / 5f || vx > 900f) && idx > 0) n--
            animTo(n)
        }

        private fun detect(e: MotionEvent) {
            val dx = e.x - downX; val dy = e.y - downY
            if (Math.abs(dx) > slop && Math.abs(dx) > Math.abs(dy)) mode = 1
            else if (-dy > slop * 2 && Math.abs(dy) > Math.abs(dx)) mode = 2
        }

        override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.x; downY = e.y; mode = 0
                    vt?.recycle(); vt = VelocityTracker.obtain(); vt?.addMovement(e)
                    va?.cancel(); off = 0f; place()
                }
                MotionEvent.ACTION_MOVE -> { vt?.addMovement(e); if (mode == 0) detect(e) }
            }
            return mode == 1 || mode == 2
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.x; downY = e.y; mode = 0
                    vt?.recycle(); vt = VelocityTracker.obtain(); vt?.addMovement(e)
                    handler.postDelayed(longR, 600)
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    vt?.addMovement(e)
                    if (mode == 0) detect(e)
                    if (Math.abs(e.x - downX) > slop || Math.abs(e.y - downY) > slop) handler.removeCallbacks(longR)
                    if (mode == 1) {
                        val dx = e.x - downX
                        off = if ((idx == 0 && dx > 0) || (idx == pages.size - 1 && dx < 0)) dx * 0.35f else dx
                        place()
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(longR)
                    vt?.addMovement(e); vt?.computeCurrentVelocity(1000)
                    val vx = vt?.xVelocity ?: 0f
                    val vy = vt?.yVelocity ?: 0f
                    if (mode == 1) settle(vx)
                    else if (mode == 2 && e.actionMasked == MotionEvent.ACTION_UP && (downY - e.y > dp(70) || vy < -1600f)) onSwipeUp()
                    mode = 0; vt?.recycle(); vt = null
                }
            }
            return true
        }
    }

    // ---------- ícones estilo iOS ----------
    private fun styled(d: Drawable, s: Int, shp: Int): Bitmap {
        val bm = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bm)
        if (shp == 2) { d.setBounds(0, 0, s, s); d.draw(c); return bm }
        val r = if (shp == 1) s / 2f else s * 0.225f
        c.clipPath(Path().apply { addRoundRect(RectF(0f, 0f, s.toFloat(), s.toFloat()), r, r, Path.Direction.CW) })
        if (Build.VERSION.SDK_INT >= 26 && d is AdaptiveIconDrawable) {
            val o = (s * 0.25f).toInt()
            d.background?.apply { setBounds(-o, -o, s + o, s + o); draw(c) }
            d.foreground?.apply { setBounds(-o, -o, s + o, s + o); draw(c) }
        } else {
            c.drawColor(Color.parseColor("#F2F2F7"))
            val pad = (s * 0.14f).toInt()
            d.setBounds(pad, pad, s - pad, s - pad); d.draw(c)
        }
        return bm
    }

    private fun icon(ri: ResolveInfo, s: Int, shp: Int = shape): Bitmap =
        iconCache.getOrPut(ri.activityInfo.packageName + "|" + shp + "|" + s) { styled(ri.loadIcon(packageManager), s, shp) }

    private fun label(ri: ResolveInfo) = ri.loadLabel(packageManager).toString()

    private fun loadApps() {
        apps = packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .filter { it.activityInfo.packageName != packageName }.sortedBy { label(it).lowercase() }
    }

    private fun launch(ri: ResolveInfo, from: View?) {
        val i = packageManager.getLaunchIntentForPackage(ri.activityInfo.packageName) ?: return
        val o = if (from != null) ActivityOptions.makeScaleUpAnimation(from, 0, 0, maxOf(from.width, 1), maxOf(from.height, 1)).toBundle() else null
        startActivity(i, o)
        if (drawer.visibility == View.VISIBLE) closeDrawer()
    }

    private fun appCell(ri: ResolveInfo, sz: Int, labels: Boolean) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
        addView(ImageView(this@MainActivity).apply { setImageBitmap(icon(ri, sz)) }, lp(sz, sz))
        if (labels) addView(tv(label(ri), 11f, Color.WHITE).apply {
            maxLines = 1; gravity = Gravity.CENTER; ellipsize = TextUtils.TruncateAt.END; setShadowLayer(5f, 0f, 1f, Color.BLACK)
        }, lp(MATCH_PARENT).apply { topMargin = dp(6) })
        setOnClickListener { launch(ri, this) }
        setOnLongClickListener { showAppMenu(ri, this); true }
        pressFx(this)
    }

    // ---------- dock ----------
    private fun defaultDock(): List<String> {
        val keys = listOf(listOf("phone", "telefone", "dialer"), listOf("messag", "mensag", "mms"),
            listOf("chrome", "browser", "navegador", "internet"), listOf("camera", "câmera"))
        val out = ArrayList<String>()
        for (ks in keys) {
            val m = apps.firstOrNull { ri -> val n = (ri.activityInfo.packageName + " " + label(ri)).lowercase(); ks.any { n.contains(it) } }
            if (m != null && !out.contains(m.activityInfo.packageName)) out.add(m.activityInfo.packageName)
        }
        return out
    }

    private fun dockPkgs(): List<String> {
        val s = prefs.getString("dock", null)
        if (s != null) return s.split(",").filter { it.isNotEmpty() }
        val d = defaultDock()
        prefs.edit().putString("dock", d.joinToString(",")).apply()
        return d
    }

    private fun toggleDock(pkg: String) {
        val l = dockPkgs().toMutableList()
        if (!l.remove(pkg)) { if (l.size >= 5) { toast("O dock aceita até 5 apps"); return }; l.add(pkg) }
        prefs.edit().putString("dock", l.joinToString(",")).apply()
    }

    // ---------- menu ao segurar o app ----------
    private fun showAppMenu(ri: ResolveInfo, anchor: View) {
        val pkg = ri.activityInfo.packageName
        val inDock = dockPkgs().contains(pkg)
        root.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        val opts = listOf<Pair<String, () -> Unit>>(
            Pair(if (inDock) "Remover do dock" else "Fixar no dock", { toggleDock(pkg); buildHome() }),
            Pair("Informações do app", { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))) }),
            Pair("Desinstalar", { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg"))) })
        )
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = round(Color.parseColor("#F02A2D36"), 16); setPadding(dp(6), dp(6), dp(6), dp(6))
        }
        lateinit var pw: PopupWindow
        opts.forEach { o ->
            box.addView(tv(o.first, 14f, if (o.first == "Desinstalar") Color.parseColor("#FF5A52") else Color.WHITE).apply {
                setPadding(dp(16), dp(12), dp(16), dp(12)); setOnClickListener { pw.dismiss(); o.second() }
            })
        }
        val w = dp(200)
        pw = PopupWindow(box, w, WRAP_CONTENT, true)
        pw.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT)); pw.isOutsideTouchable = true; pw.elevation = dp(16).toFloat()
        val loc = IntArray(2); anchor.getLocationOnScreen(loc)
        val dm = resources.displayMetrics
        val x = (loc[0] + anchor.width / 2 - w / 2).coerceIn(dp(8), dm.widthPixels - w - dp(8))
        val est = dp(48) * opts.size + dp(12)
        val belowY = loc[1] + anchor.height + dp(6)
        val y = if (belowY + est > dm.heightPixels - dp(20)) loc[1] - est - dp(6) else belowY
        pw.showAtLocation(root, Gravity.TOP or Gravity.START, x, maxOf(dp(24), y))
        box.pivotX = w / 2f; box.pivotY = 0f; box.alpha = 0f
        anim(box, 380, Spring(), { f -> box.alpha = minOf(1f, f * 3f); box.scaleX = 0.8f + 0.2f * f; box.scaleY = 0.8f + 0.2f * f })
    }

    // ---------- papel de parede ----------
    private fun bloom(w: Int, h: Int): Bitmap {
        val bm = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bm); val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), Color.parseColor("#55307C"), Color.parseColor("#2A1445"), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        val cx = w * 0.55f; val cy = h * 0.8f; val r = h * 0.68f
        val top = arrayOf("#F7C9AE", "#F4A27A", "#E8604A", "#C8223E", "#F29B6E", "#E4806E", "#D63E55")
        val bot = arrayOf("#D8566A", "#C0392B", "#8E1230", "#6A0F2E", "#B84A4A", "#A33250", "#7C1740")
        for (i in 0 until 7) {
            c.save(); c.rotate(-48f + i * 16f, cx, cy)
            p.shader = LinearGradient(cx, cy - r, cx, cy, Color.parseColor(top[i]), Color.parseColor(bot[i]), Shader.TileMode.CLAMP)
            c.drawOval(RectF(cx - r * 0.2f, cy - r, cx + r * 0.2f, cy), p)
            c.restore()
        }
        return bm
    }

    private fun loadWallpaper() {
        val dm = resources.displayMetrics
        val f = File(filesDir, "wp.img")
        var bmp: Bitmap? = null
        if (f.exists()) {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.path, o)
            val s = maxOf(1, maxOf(o.outWidth, o.outHeight) / 1800)
            bmp = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
        }
        val b = bmp ?: bloom(dm.widthPixels, dm.heightPixels)
        wallBmp = b; bg.setImageBitmap(b)
        root.setBackgroundColor(b.getPixel(0, 0))
        applyFit()
    }

    private fun applyFit() {
        val custom = File(filesDir, "wp.img").exists()
        bg.scaleType = if (!custom) ImageView.ScaleType.CENTER_CROP else when (gi("fit", 0)) {
            1 -> ImageView.ScaleType.FIT_CENTER
            2 -> ImageView.ScaleType.FIT_XY
            else -> ImageView.ScaleType.CENTER_CROP
        }
    }

    private fun pickWall() { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), PICK) }

    private fun resetWall() {
        File(filesDir, "wp.img").delete(); loadWallpaper()
        if (st.visibility == View.VISIBLE && stPage == "wall") renderSt(false)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == PICK && res == RESULT_OK && data?.data != null) {
            contentResolver.openInputStream(data.data!!)?.use { input ->
                File(filesDir, "wp.img").outputStream().use { input.copyTo(it) }
            }
            loadWallpaper()
            if (st.visibility == View.VISIBLE && stPage == "wall") renderSt(false)
        }
    }

    // ---------- ciclo de vida ----------
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        buildUI()
    }

    override fun onResume() {
        super.onResume()
        val before = apps.map { it.activityInfo.packageName }
        loadApps()
        if (before != apps.map { it.activityInfo.packageName }) buildHome()
    }

    override fun onNewIntent(i: Intent?) {
        super.onNewIntent(i)
        closeOverlays(); pager.go(0)
    }

    override fun onBackPressed() {
        when {
            welcome.visibility == View.VISIBLE -> { if (wStep > 0) { wStep--; renderWelcome() } }
            st.visibility == View.VISIBLE -> if (stPage != "main") { stPage = "main"; renderSt(false) } else closeSettings()
            drawer.visibility == View.VISIBLE -> closeDrawer()
        }
    }

    private fun closeOverlays() { if (drawer.visibility == View.VISIBLE) closeDrawer(); if (st.visibility == View.VISIBLE) closeSettings() }

    private fun rebuild(page: String?) { iconCache.clear(); pendingPage = page; buildUI() }

    private fun buildUI() {
        root = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#2A1445")) }
        bg = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        root.addView(bg, MATCH_PARENT, MATCH_PARENT)
        pager = Pager()
        pager.onPage = { updateDots(it) }
        pager.onSwipeUp = { if (gb("swipeUp", true)) openDrawer() }
        pager.onLong = { if (gb("longSet", true)) openSettings("main") }
        root.addView(pager, MATCH_PARENT, MATCH_PARENT)
        dots = LinearLayout(this).apply { gravity = Gravity.CENTER }
        root.addView(dots, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
        arrow = tv("⌃", 22f, Color.WHITE).apply { setShadowLayer(6f, 0f, 1f, Color.BLACK); setOnClickListener { openDrawer() } }
        root.addView(arrow, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
        dockV = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; background = round(Color.parseColor("#33FFFFFF"), 30) }
        root.addView(dockV, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.BOTTOM).apply { setMargins(dp(14), 0, dp(14), dp(24)) })
        drawer = buildDrawer(); root.addView(drawer, MATCH_PARENT, MATCH_PARENT)
        st = buildSettings(); root.addView(st, MATCH_PARENT, MATCH_PARENT)
        welcome = buildWelcome(); root.addView(welcome, MATCH_PARENT, MATCH_PARENT)
        welcome.visibility = if (gb("setup", false)) View.GONE else View.VISIBLE
        setContentView(root)
        loadWallpaper()
        loadApps()
        buildHome()
        if (!gb("setup", false)) { wStep = 0; renderWelcome() }
        pendingPage?.let { pendingPage = null; openSettings(it) }
    }

    // ---------- tela inicial ----------
    private fun buildHome() {
        val dm = resources.displayMetrics
        val sz = dp(gi("icon", 56)); val lab = gb("labels", true); val c = gi("cols", 4)
        val dockPk = dockPkgs()
        val dockApps = dockPk.mapNotNull { pk -> apps.firstOrNull { it.activityInfo.packageName == pk } }
        dockV.removeAllViews()
        dockV.visibility = if (dockApps.isEmpty()) View.GONE else View.VISIBLE
        dockV.setPadding(dp(8), dp(12), dp(8), dp(12))
        dockApps.forEach { ri ->
            val cell = FrameLayout(this).apply {
                addView(ImageView(this@MainActivity).apply { setImageBitmap(icon(ri, sz)) }, FrameLayout.LayoutParams(sz, sz, Gravity.CENTER))
                setOnClickListener { launch(ri, this) }
                setOnLongClickListener { showAppMenu(ri, this); true }
                pressFx(this)
            }
            dockV.addView(cell, lp(0, sz, 1f))
        }
        val dockTotal = if (dockApps.isEmpty()) dp(16) else sz + dp(48)
        val top = statusH() + dp(16)
        val rowH = sz + (if (lab) dp(24) else 0) + dp(24)
        val rows = maxOf(1, (dm.heightPixels - top - dockTotal - dp(70)) / rowH)
        val list = apps.filter { ri -> !dockPk.contains(ri.activityInfo.packageName) }
        val chunks = if (list.isEmpty()) listOf(emptyList<ResolveInfo>()) else list.chunked(c * rows)
        val cellW = dm.widthPixels / c
        val views = chunks.map { chunk ->
            FrameLayout(this).also { pg ->
                chunk.forEachIndexed { i, ri ->
                    pg.addView(appCell(ri, sz, lab), FrameLayout.LayoutParams(cellW, rowH).apply {
                        leftMargin = (i % c) * cellW; topMargin = top + (i / c) * rowH
                    })
                }
            }
        }
        pager.set(views)
        dots.removeAllViews()
        if (views.size > 1) views.forEach { _ ->
            dots.addView(View(this).apply { background = round(Color.WHITE, 4) }, lp(dp(7), dp(7)).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
        (dots.layoutParams as FrameLayout.LayoutParams).bottomMargin = dockTotal + dp(10)
        (arrow.layoutParams as FrameLayout.LayoutParams).bottomMargin = dockTotal + dp(24)
        dots.requestLayout(); arrow.requestLayout()
        updateDots(pager.idx)
    }

    private fun updateDots(i: Int) { for (k in 0 until dots.childCount) dots.getChildAt(k).alpha = if (k == i) 1f else 0.4f }

    // ---------- gaveta de apps (deslizar para cima) ----------
    private fun buildDrawer(): FrameLayout {
        val d = FrameLayout(this).apply { visibility = View.GONE; isClickable = true; setBackgroundColor(Color.parseColor("#F00B0D14")) }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), statusH() + dp(14), dp(12), dp(8)) }
        dSearch = EditText(this).apply {
            hint = "🔍  Pesquisar apps"; setHintTextColor(Color.parseColor("#99FFFFFF")); setTextColor(Color.WHITE); textSize = 15f; setSingleLine()
            background = round(Color.parseColor("#33FFFFFF"), 16); setPadding(dp(16), dp(12), dp(16), dp(12))
            addTextChangedListener(watcher { renderDrawer() })
        }
        col.addView(dSearch, lp(MATCH_PARENT))
        dGrid = GridLayout(this)
        col.addView(ScrollView(this).apply { addView(dGrid); isVerticalScrollBarEnabled = false }, lp(MATCH_PARENT, 0, 1f).apply { topMargin = dp(12) })
        d.addView(col, MATCH_PARENT, MATCH_PARENT)
        return d
    }

    private fun renderDrawer() {
        dGrid.removeAllViews()
        val c = gi("cols", 4); dGrid.columnCount = c
        val w = (resources.displayMetrics.widthPixels - dp(24)) / c
        val q = dSearch.text.toString().trim().lowercase()
        apps.filter { q.isEmpty() || label(it).lowercase().contains(q) }.forEach { ri ->
            dGrid.addView(appCell(ri, dp(gi("icon", 56)), true), GridLayout.LayoutParams().apply { width = w; height = WRAP_CONTENT; setMargins(0, dp(8), 0, dp(8)) })
        }
    }

    private fun openDrawer() { dSearch.setText(""); renderDrawer(); showSheet(drawer) }

    private fun closeDrawer() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(dSearch.windowToken, 0)
        hideSheet(drawer)
    }

    // ---------- configurações (estilo HyperOS) ----------
    private class RD(val e: String, val c: Int, val t: String, val v: String?, val a: () -> Unit)

    private fun buildSettings(): FrameLayout {
        val o = FrameLayout(this).apply { visibility = View.GONE; isClickable = true; setBackgroundColor(BG) }
        stBody = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), statusH() + dp(12), dp(16), dp(48)) }
        o.addView(ScrollView(this).apply { addView(stBody); isVerticalScrollBarEnabled = false }, MATCH_PARENT, MATCH_PARENT)
        return o
    }

    private fun openSettings(page: String) { stPage = page; renderSt(true); showFull(st) }

    private fun closeSettings() {
        hideFull(st)
        if (homeDirty) { homeDirty = false; buildHome() }
    }

    private fun goPage(p: String) { stPage = p; renderSt(true) }

    private fun renderSt(forward: Boolean) {
        stBody.removeAllViews()
        when (stPage) {
            "wall" -> pageWall()
            "home" -> pageHome()
            "icons" -> pageIcons()
            "dock" -> pageDock()
            "anim" -> pageAnim()
            "theme" -> pageTheme()
            "gest" -> pageGest()
            "about" -> pageAbout()
            else -> pageMain()
        }
        val dx = if (forward) dp(40) else -dp(40)
        stBody.alpha = 0f; stBody.translationX = dx.toFloat()
        anim(stBody, 420, Spring(), { f -> stBody.alpha = minOf(1f, f * 3f); stBody.translationX = (1f - f) * dx })
    }

    private fun card(parent: LinearLayout, rows: List<View>) {
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = round(CARD, 16) }
        rows.forEachIndexed { i, r ->
            if (i > 0) c.addView(View(this).apply { setBackgroundColor(DIV) }, lp(MATCH_PARENT, 1).apply { leftMargin = dp(60) })
            c.addView(r)
        }
        parent.addView(c, lp(MATCH_PARENT).apply { bottomMargin = dp(14) })
    }

    private fun setRow(e: String, c: Int, t: String, v: String?, a: (() -> Unit)?): View = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12))
        addView(tv(e, 17f, Color.WHITE).apply { gravity = Gravity.CENTER; background = round(c, 9) }, lp(dp(34), dp(34)))
        addView(tv(t, 15f, TXT).apply { setPadding(dp(14), 0, 0, 0) }, lp(0, WRAP_CONTENT, 1f))
        if (v != null) addView(tv(v, 13f, SUB))
        if (a != null) { addView(tv("  ›", 18f, SUB)); background = pressBg(); setOnClickListener { a() } }
    }

    private fun switchRow(t: String, key: String, def: Boolean, onChange: ((Boolean) -> Unit)? = null): View = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(10), dp(14), dp(10))
        addView(tv(t, 15f, TXT), lp(0, WRAP_CONTENT, 1f))
        addView(Switch(this@MainActivity).apply {
            isChecked = gb(key, def)
            thumbTintList = ColorStateList.valueOf(Color.WHITE)
            trackTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(Color.parseColor("#34C759"), pick("#C8CCD6", "#454B58")))
            setOnCheckedChangeListener { _, ck -> prefs.edit().putBoolean(key, ck).apply(); onChange?.invoke(ck) }
        })
    }

    private fun segRow(opts: List<String>, sel: Int, on: (Int) -> Unit): View = LinearLayout(this).apply {
        setPadding(dp(12), dp(12), dp(12), dp(12))
        val inner = LinearLayout(this@MainActivity).apply { background = round(FIELD, 12); setPadding(dp(3), dp(3), dp(3), dp(3)) }
        opts.forEachIndexed { i, o ->
            inner.addView(tv(o, 13f, if (i == sel) Color.WHITE else TXT).apply {
                gravity = Gravity.CENTER; setPadding(dp(4), dp(10), dp(4), dp(10))
                background = round(if (i == sel) ACC else Color.TRANSPARENT, 10); setOnClickListener { on(i) }
            }, lp(0, WRAP_CONTENT, 1f))
        }
        addView(inner, lp(MATCH_PARENT))
    }

    private fun sliderRow(t: String, lo: Int, hi: Int, v: Int, unit: String, done: (Int) -> Unit): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(8))
        val top = LinearLayout(this@MainActivity)
        val lbl = tv(v.toString() + unit, 14f, SUB)
        top.addView(tv(t, 15f, TXT), lp(0, WRAP_CONTENT, 1f)); top.addView(lbl)
        addView(top, lp(MATCH_PARENT))
        addView(SeekBar(this@MainActivity).apply {
            this.max = hi - lo; progress = v - lo
            progressTintList = ColorStateList.valueOf(ACC); thumbTintList = ColorStateList.valueOf(ACC)
            progressBackgroundTintList = ColorStateList.valueOf(DIV)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) { lbl.text = (p + lo).toString() + unit }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) { done((sb?.progress ?: 0) + lo) }
            })
        }, lp(MATCH_PARENT))
    }

    private fun sectionLabel(t: String) = stBody.addView(tv(t.uppercase(), 11f, SUB, true).apply { setPadding(dp(6), dp(4), 0, dp(8)) })

    private fun header(title: String) {
        stBody.addView(tv("‹  Configurações", 15f, ACC).apply {
            setPadding(0, dp(8), dp(12), dp(8)); setOnClickListener { stPage = "main"; renderSt(false) }
        })
        stBody.addView(tv(title, 28f, TXT, true), lp(MATCH_PARENT).apply { topMargin = dp(4); bottomMargin = dp(14) })
    }

    private fun groups(): List<List<RD>> = listOf(
        listOf(RD("🚀", ACC, "Core Launcher", "v1.0") { goPage("about") }),
        listOf(
            RD("🖼️", Color.parseColor("#FF9F0A"), "Papel de parede", null) { goPage("wall") },
            RD("🏠", Color.parseColor("#34C759"), "Tela inicial", null) { goPage("home") },
            RD("🎨", Color.parseColor("#AF52DE"), "Ícones", null) { goPage("icons") },
            RD("📱", Color.parseColor("#30B0C7"), "Dock", null) { goPage("dock") }
        ),
        listOf(
            RD("✨", Color.parseColor("#FF375F"), "Animações", null) { goPage("anim") },
            RD("🌓", Color.parseColor("#5E5CE6"), "Tema", null) { goPage("theme") },
            RD("👆", Color.parseColor("#8E8E93"), "Gestos", null) { goPage("gest") }
        ),
        listOf(
            RD("👋", Color.parseColor("#FF9F0A"), "Rever boas-vindas", null) { closeSettings(); wStep = 0; welcome.visibility = View.VISIBLE; renderWelcome() },
            RD("🏠", ACC, "Definir como launcher padrão", null) { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
        )
    )

    private fun renderMainList(q: String) {
        mainList.removeAllViews()
        groups().forEach { g ->
            val f = g.filter { q.isEmpty() || it.t.lowercase().contains(q) }
            if (f.isNotEmpty()) card(mainList, f.map { setRow(it.e, it.c, it.t, it.v, it.a) })
        }
    }

    private fun pageMain() {
        stBody.addView(tv("Configurações", 32f, TXT, true), lp(MATCH_PARENT).apply { topMargin = dp(8); bottomMargin = dp(14) })
        stBody.addView(EditText(this).apply {
            hint = "🔍  Pesquisar"; textSize = 14f; setSingleLine(); setTextColor(TXT); setHintTextColor(SUB)
            background = round(FIELD, 14); setPadding(dp(16), dp(12), dp(16), dp(12))
            addTextChangedListener(watcher { renderMainList(it.trim().lowercase()) })
        }, lp(MATCH_PARENT).apply { bottomMargin = dp(16) })
        mainList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        stBody.addView(mainList, lp(MATCH_PARENT))
        renderMainList("")
    }

    private fun pageWall() {
        header("Papel de parede")
        stBody.addView(ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP; setImageBitmap(wallBmp)
            background = round(CARD, 16); clipToOutline = true; outlineProvider = ViewOutlineProvider.BACKGROUND
        }, lp(MATCH_PARENT, dp(260)).apply { bottomMargin = dp(14) })
        card(stBody, listOf(
            setRow("🖼️", Color.parseColor("#FF9F0A"), "Escolher da galeria", null) { pickWall() },
            setRow("↺", Color.parseColor("#8E8E93"), "Restaurar padrão", null) { resetWall() }
        ))
        sectionLabel("Ajuste (só para fotos da galeria)")
        card(stBody, listOf(segRow(listOf("Preencher", "Ajustar", "Esticar"), gi("fit", 0)) { si("fit", it); applyFit(); renderSt(false) }))
    }

    private fun pageHome() {
        header("Tela inicial")
        card(stBody, listOf(sliderRow("Colunas", 3, 6, gi("cols", 4), "") { si("cols", it); rebuild("home") }))
        card(stBody, listOf(switchRow("Mostrar nomes dos apps", "labels", true) { rebuild("home") }))
    }

    private fun pageIcons() {
        header("Ícones")
        sectionLabel("Formato")
        card(stBody, listOf(segRow(listOf("Squircle", "Círculo", "Original"), shape) { si("shape", it); rebuild("icons") }))
        card(stBody, listOf(sliderRow("Tamanho do ícone", 44, 76, gi("icon", 56), " dp") { si("icon", it); rebuild("icons") }))
    }

    private fun pageDock() {
        header("Dock")
        stBody.addView(tv("Escolha até 5 apps para ficarem fixos embaixo.", 13f, SUB).apply { setPadding(dp(4), 0, 0, dp(10)) })
        val rows = apps.map { ri ->
            val pkg = ri.activityInfo.packageName
            val mark = tv("", 20f)
            fun paint() { val on = dockPkgs().contains(pkg); mark.text = if (on) "☑" else "☐"; mark.setTextColor(if (on) ACC else SUB) }
            paint()
            LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(10)); background = pressBg()
                addView(ImageView(this@MainActivity).apply { setImageBitmap(icon(ri, dp(32))) }, lp(dp(32), dp(32)))
                addView(tv(label(ri), 15f, TXT).apply { setPadding(dp(12), 0, 0, 0) }, lp(0, WRAP_CONTENT, 1f))
                addView(mark)
                setOnClickListener { toggleDock(pkg); homeDirty = true; paint() }
            }
        }
        card(stBody, rows)
    }

    private fun pageAnim() {
        header("Animações")
        card(stBody, listOf(switchRow("Animações fluidas (mola)", "anim", true)))
        sectionLabel("Velocidade")
        card(stBody, listOf(segRow(listOf("Rápida", "Normal", "Lenta"), gi("speed", 1)) { si("speed", it); renderSt(false) }))
        stBody.addView(tv("As animações usam efeito de mola, como no iOS.", 12f, SUB).apply { setPadding(dp(6), 0, 0, 0) })
    }

    private fun pageTheme() {
        header("Tema")
        card(stBody, listOf(segRow(listOf("Claro", "Escuro", "Automático"), gi("theme", 2)) { si("theme", it); rebuild("theme") }))
        stBody.addView(tv("Automático segue o tema do sistema.", 12f, SUB).apply { setPadding(dp(6), 0, 0, 0) })
    }

    private fun pageGest() {
        header("Gestos")
        card(stBody, listOf(
            switchRow("Deslizar para cima abre os apps", "swipeUp", true),
            switchRow("Segurar na tela abre as configurações", "longSet", true)
        ))
    }

    private fun pageAbout() {
        header("Sobre")
        card(stBody, listOf(
            setRow("🚀", ACC, "Core Launcher", "Versão 1.0", null),
            setRow("🏠", Color.parseColor("#34C759"), "Apps instalados", apps.size.toString(), null)
        ))
    }

    // ---------- boas-vindas ----------
    private fun buildWelcome(): FrameLayout {
        val w = FrameLayout(this).apply {
            isClickable = true
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#2A1450"), Color.parseColor("#9C2B5E"), Color.parseColor("#F58A3A")))
        }
        wBox = FrameLayout(this)
        w.addView(wBox, MATCH_PARENT, MATCH_PARENT)
        return w
    }

    private fun pillBtn(t: String, filled: Boolean, click: () -> Unit) =
        tv(t, 15f, if (filled) Color.parseColor("#2A1450") else Color.WHITE, true).apply {
            gravity = Gravity.CENTER; setPadding(dp(24), dp(15), dp(24), dp(15))
            background = round(if (filled) Color.WHITE else Color.parseColor("#33FFFFFF"), 28)
            setOnClickListener { click() }; pressFx(this)
        }

    private fun tile(content: View, sel: Boolean, click: () -> Unit): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(8), dp(18), dp(8), dp(18))
        background = round(Color.parseColor(if (sel) "#55FFFFFF" else "#26FFFFFF"), 18, if (sel) Color.WHITE else 0)
        addView(content); setOnClickListener { click() }; pressFx(this)
    }

    private fun tileRow(vararg ts: View): View = LinearLayout(this).apply {
        ts.forEachIndexed { i, t -> addView(t, lp(0, WRAP_CONTENT, 1f).apply { if (i < ts.size - 1) rightMargin = dp(10) }) }
    }

    private fun wScaffold(title: String, sub: String, content: View, btn: String, next: () -> Unit) {
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), statusH() + dp(40), dp(24), dp(36)) }
        c.addView(tv(title, 28f, Color.WHITE, true))
        c.addView(tv(sub, 14f, Color.parseColor("#CCFFFFFF")).apply { setPadding(0, dp(8), 0, dp(24)) })
        c.addView(content, lp(MATCH_PARENT))
        c.addView(View(this), lp(1, 0, 1f))
        c.addView(pillBtn(btn, true) { next() }, lp(MATCH_PARENT))
        wBox.addView(c, MATCH_PARENT, MATCH_PARENT)
    }

    private fun wLabel(e: String, t: String): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
        addView(tv(e, 30f, Color.WHITE).apply { gravity = Gravity.CENTER })
        addView(tv(t, 13f, Color.WHITE, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) })
    }

    private fun sampleIcon(): Drawable =
        apps.firstOrNull()?.loadIcon(packageManager) ?: resources.getDrawable(android.R.drawable.sym_def_app_icon, theme)

    private fun renderWelcome() {
        wBox.removeAllViews()
        when (wStep) {
            0 -> welcomeIntro()
            1 -> {
                val cur = gi("theme", 2)
                wScaffold("Escolha o tema", "Você pode mudar depois nas configurações.",
                    tileRow(tile(wLabel("☀️", "Claro"), cur == 0) { si("theme", 0); renderWelcome() },
                        tile(wLabel("🌙", "Escuro"), cur == 1) { si("theme", 1); renderWelcome() },
                        tile(wLabel("🌗", "Auto"), cur == 2) { si("theme", 2); renderWelcome() }),
                    "Continuar") { wStep = 2; renderWelcome() }
            }
            2 -> {
                val cur = shape
                val names = listOf("Squircle", "Círculo", "Original")
                val ts = names.mapIndexed { i, n ->
                    tile(LinearLayout(this).apply {
                        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                        addView(ImageView(this@MainActivity).apply { setImageBitmap(styled(sampleIcon(), dp(56), i)) }, lp(dp(56), dp(56)))
                        addView(tv(n, 12f, Color.WHITE, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) })
                    }, cur == i) { si("shape", i); iconCache.clear(); renderWelcome() }
                }
                wScaffold("Formato dos ícones", "Deixe os apps com o visual que você gosta.", tileRow(*ts.toTypedArray()), "Continuar") { wStep = 3; renderWelcome() }
            }
            3 -> wScaffold("Papel de parede", "Escolha uma foto da galeria ou use o padrão.",
                tileRow(tile(wLabel("🖼️", "Galeria"), false) { pickWall() },
                    tile(wLabel("✨", "Padrão"), false) { File(filesDir, "wp.img").delete(); loadWallpaper(); toast("Papel de parede padrão") }),
                "Continuar") { wStep = 4; renderWelcome() }
            else -> wScaffold("Tudo pronto!", "Defina o Core Launcher como tela inicial para usar de verdade.",
                pillBtn("🏠  Definir como launcher padrão", false) { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) },
                "Finalizar") { finishWelcome() }
        }
        if (wStep > 0) {
            wBox.alpha = 0f; wBox.translationX = dp(40).toFloat()
            anim(wBox, 420, Spring(), { f -> wBox.alpha = minOf(1f, f * 3f); wBox.translationX = (1f - f) * dp(40) })
        } else { wBox.alpha = 1f; wBox.translationX = 0f }
    }

    private fun welcomeIntro() {
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(24), 0, dp(24), dp(36)) }
        val t1 = tv("WELCOME", 15f, Color.parseColor("#E6FFFFFF")).apply { letterSpacing = 0.5f; gravity = Gravity.CENTER }
        val t2 = tv("CORE", 54f, Color.WHITE, true).apply { letterSpacing = 0.12f; gravity = Gravity.CENTER }
        val t3 = tv("LAUNCHER", 54f, Color.WHITE, true).apply { letterSpacing = 0.12f; gravity = Gravity.CENTER }
        val t4 = tv("Vamos deixar seu celular do seu jeito.", 14f, Color.parseColor("#CCFFFFFF")).apply { gravity = Gravity.CENTER; setPadding(0, dp(18), 0, 0) }
        val all = listOf(t1, t2, t3, t4)
        all.forEach { c.addView(it, lp(MATCH_PARENT)) }
        c.addView(pillBtn("Começar", true) { wStep = 1; renderWelcome() }, lp(MATCH_PARENT).apply { topMargin = dp(48) })
        wBox.addView(c, MATCH_PARENT, MATCH_PARENT)
        all.forEachIndexed { i, v ->
            v.alpha = 0f; v.scaleX = 0.7f; v.scaleY = 0.7f
            handler.postDelayed({
                anim(v, 700, Spring(), { f -> v.alpha = minOf(1f, f * 2f); v.scaleX = 0.7f + 0.3f * f; v.scaleY = 0.7f + 0.3f * f })
            }, 150L * i)
        }
    }

    private fun finishWelcome() {
        prefs.edit().putBoolean("setup", true).apply()
        anim(welcome, 300, DecelerateInterpolator(), { f -> welcome.alpha = 1f - f }, { rebuild(null) })
    }
}
