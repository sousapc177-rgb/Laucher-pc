package com.pclauncher

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.TimeInterpolator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.ActivityOptions
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.*
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.InputMethodManager
import android.webkit.MimeTypeMap
import android.widget.*
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var bg: ImageView
    private lateinit var rootV: FrameLayout
    private lateinit var tray: TextView
    private lateinit var taskIcons: LinearLayout
    private lateinit var panel: LinearLayout
    private lateinit var body: LinearLayout
    private lateinit var search: EditText
    private lateinit var ex: LinearLayout
    private lateinit var exList: LinearLayout
    private lateinit var exAddr: TextView
    private lateinit var exStatus: TextView
    private lateinit var exTitle: TextView
    private lateinit var exSearch: EditText
    private lateinit var stg: LinearLayout
    private lateinit var stgBody: LinearLayout
    private lateinit var stgTitle: TextView
    private var stgPage = "home"
    private var apps = listOf<ResolveInfo>()
    private var allView = false
    private var exMax = false
    private var byDate = false
    private var dark = false
    private var fit = 1 // 0 preencher, 1 ajustar (ver inteiro), 2 esticar
    private var reopen = false
    private val hist = ArrayList<File>()
    private val prefs by lazy { getSharedPreferences("p", MODE_PRIVATE) }
    @Suppress("DEPRECATION")
    private val sd: File = Environment.getExternalStorageDirectory()
    private var cur: File = sd
    private val handler = Handler(Looper.getMainLooper())
    private val PICK = 42
    private val BLUE = Color.parseColor("#0078D4")
    private val dfWide = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
    private val dfNarrow = SimpleDateFormat("dd/MM/yy", Locale.getDefault())

    // ---------- tema claro / escuro ----------
    private fun pick(l: String, d: String) = Color.parseColor(if (dark) d else l)
    private val TXT: Int get() = pick("#1F1F1F", "#F2F2F2")
    private val SUB: Int get() = pick("#707070", "#9AA0AC")
    private val BORDER: Int get() = pick("#D5DAE3", "#3B4150")
    private val PANEL: Int get() = pick("#F3F5F9", "#242936")
    private val FOOT: Int get() = pick("#E6EAF1", "#1C202B")
    private val FIELD: Int get() = pick("#FFFFFF", "#2F3544")
    private val BAR: Int get() = pick("#EBF1F3F8", "#EB1E2230")
    private val WINBG: Int get() = pick("#FBFBFD", "#222733")
    private val TITLE: Int get() = pick("#EAF0F8", "#1A1E29")
    private val CONTENT: Int get() = pick("#FFFFFF", "#272C3A")
    private val PRESS: Int get() = pick("#DCE9FA", "#36425E")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val panelW: Int get() = minOf(resources.displayMetrics.widthPixels - dp(16), dp(520))
    private val explorerW: Int get() = minOf(resources.displayMetrics.widthPixels - dp(12), dp(900))
    private val settingsW: Int get() = minOf(resources.displayMetrics.widthPixels - dp(12), dp(720))

    private fun lp(w: Int, h: Int = WRAP_CONTENT, wt: Float = 0f) = LinearLayout.LayoutParams(w, h, wt)

    private fun tv(t: String, sp: Float, c: Int = TXT, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = sp; setTextColor(c); if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun round(c: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply {
        setColor(c); cornerRadius = dp(r).toFloat(); if (stroke != 0) setStroke(dp(1), stroke)
    }

    private fun pressBg() = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_pressed), round(PRESS, 6))
        addState(intArrayOf(), ColorDrawable(Color.TRANSPARENT))
    }

    // ---------- animações estilo iOS (mola) ----------
    private class Spring : android.view.animation.Interpolator {
        override fun getInterpolation(t: Float): Float =
            if (t >= 1f) 1f else (1.0 - Math.exp(-7.0 * t) * Math.cos(9.0 * t)).toFloat()
    }

    private fun anim(v: View, dur: Long, ip: TimeInterpolator, upd: (Float) -> Unit, end: (() -> Unit)? = null) {
        (v.tag as? ValueAnimator)?.cancel()
        val a = ValueAnimator.ofFloat(0f, 1f).apply { duration = dur; interpolator = ip }
        a.addUpdateListener { upd(it.animatedValue as Float) }
        a.addListener(object : AnimatorListenerAdapter() {
            var cancelled = false
            override fun onAnimationCancel(an: Animator) { cancelled = true }
            override fun onAnimationEnd(an: Animator) {
                v.setLayerType(View.LAYER_TYPE_NONE, null)
                if (!cancelled) end?.invoke()
            }
        })
        v.tag = a
        v.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        a.start()
    }

    private fun showPanel(v: View) {
        v.visibility = View.VISIBLE; v.alpha = 0f
        v.post {
            v.pivotX = v.width / 2f; v.pivotY = v.height.toFloat()
            anim(v, 480, Spring(), { f ->
                v.alpha = minOf(1f, f * 3f)
                v.scaleX = 0.88f + 0.12f * f; v.scaleY = 0.88f + 0.12f * f
                v.translationY = (1f - f) * dp(48)
            })
        }
    }

    private fun hidePanel(v: View) {
        if (v.visibility != View.VISIBLE) return
        anim(v, 200, AccelerateInterpolator(1.3f), { f ->
            v.alpha = 1f - f; v.scaleX = 1f - 0.05f * f; v.scaleY = 1f - 0.05f * f; v.translationY = f * dp(24)
        }, { v.visibility = View.GONE })
    }

    private fun pressFx(v: View) {
        v.setOnTouchListener { x, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN)
                x.animate().scaleX(0.88f).scaleY(0.88f).setDuration(100).setInterpolator(DecelerateInterpolator()).start()
            else if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL)
                x.animate().scaleX(1f).scaleY(1f).setDuration(420).setInterpolator(Spring()).start()
            false
        }
    }

    // logo do Windows 11
    inner class WinLogo : View(this@MainActivity) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onMeasure(w: Int, hh: Int) = setMeasuredDimension(dp(20), dp(20))
        override fun onDraw(c: Canvas) {
            p.shader = LinearGradient(0f, 0f, width.toFloat(), 0f, Color.parseColor("#1FA9FF"), Color.parseColor("#3C78F6"), Shader.TileMode.CLAMP)
            val s = width / 2f - 1.5f; val big = s * 0.32f; val sm = 1.5f
            for (x in 0..1) for (y in 0..1) {
                val l = x * (s + 3f); val t = y * (s + 3f)
                val tl = if (x == 0 && y == 0) big else sm
                val tr = if (x == 1 && y == 0) big else sm
                val br = if (x == 1 && y == 1) big else sm
                val bl = if (x == 0 && y == 1) big else sm
                val path = Path().apply { addRoundRect(RectF(l, t, l + s, t + s), floatArrayOf(tl, tl, tr, tr, br, br, bl, bl), Path.Direction.CW) }
                c.drawPath(path, p)
            }
        }
    }

    private fun bloom(w: Int, h: Int): Bitmap {
        val bm = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bm); val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), Color.parseColor("#DCEAF7"), Color.parseColor("#9FC3E8"), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        val cx = w / 2f; val cy = h * 0.5f; val r = minOf(w, h) * 0.55f
        val cols = intArrayOf(Color.parseColor("#2F86F5"), Color.parseColor("#1B5FE0"), Color.parseColor("#0A3FB5"))
        for (i in 0 until 6) {
            c.save(); c.rotate(i * 60f + 15f, cx, cy)
            p.shader = LinearGradient(cx, cy - r, cx, cy, intArrayOf(cols[i % 3], Color.parseColor("#7FB8FF")), null, Shader.TileMode.CLAMP)
            c.drawOval(RectF(cx - r * 0.38f, cy - r, cx + r * 0.38f, cy + r * 0.05f), p)
            c.restore()
        }
        return bm
    }

    private val ticker = object : Runnable {
        override fun run() {
            val n = Date()
            tray.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(n) + "\n" +
                SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(n)
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(st: Bundle?) {
        super.onCreate(st)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN)
        dark = prefs.getBoolean("dark", false)
        fit = prefs.getInt("fit", 1)
        buildUI()
    }

    private fun buildUI() {
        val dm = resources.displayMetrics
        val root = FrameLayout(this)
        rootV = root
        root.setBackgroundColor(Color.parseColor("#9FC3E8"))
        bg = ImageView(this).apply { setImageBitmap(bloom(dm.widthPixels, dm.heightPixels)) }
        root.addView(bg, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        root.setOnClickListener { closeMenu() }
        root.setOnLongClickListener { pickWallpaper(); true }
        root.setOnContextClickListener { pickWallpaper(); true }

        val desk = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        desk.addView(deskIcon("🗑️", "Lixeira") { Toast.makeText(this, "Lixeira vazia", Toast.LENGTH_SHORT).show() })
        desk.addView(deskIcon("🌐", "Navegador") { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"))) })
        root.addView(desk, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { setMargins(dp(6), dp(40), 0, 0) })

        ex = buildExplorer()
        root.addView(ex, FrameLayout.LayoutParams(explorerW, (dm.heightPixels * 0.76).toInt(), Gravity.CENTER_HORIZONTAL or Gravity.TOP).apply { topMargin = dp(36) })
        stg = buildSettings()
        root.addView(stg, FrameLayout.LayoutParams(settingsW, (dm.heightPixels * 0.76).toInt(), Gravity.CENTER_HORIZONTAL or Gravity.TOP).apply { topMargin = dp(36) })

        // menu iniciar
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE; isClickable = true
            background = round(PANEL, 12, BORDER); elevation = dp(12).toFloat()
        }
        search = EditText(this).apply {
            hint = "🔍  Digite aqui para pesquisar"; textSize = 13f; setSingleLine(); setTextColor(TXT); setHintTextColor(SUB)
            background = round(FIELD, 6, BORDER); setPadding(dp(12), dp(10), dp(12), dp(10))
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { render() }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        panel.addView(search, lp(MATCH_PARENT).apply { setMargins(dp(16), dp(16), dp(16), dp(4)) })
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), 0, dp(16), dp(8)) }
        panel.addView(ScrollView(this).apply { addView(body) }, lp(MATCH_PARENT, 0, 1f))
        val foot = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(FOOT); setPadding(dp(24), dp(12), dp(24), dp(12))
        }
        val user = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setOnClickListener { openSettings("personal") } }
        user.addView(tv("👤", 18f)); user.addView(tv("  Usuário", 13f))
        foot.addView(user, lp(0, WRAP_CONTENT, 1f))
        foot.addView(tv("⚙", 20f).apply { setPadding(dp(8), 0, dp(14), 0); setOnClickListener { openSettings("home") } })
        foot.addView(tv("⏻", 20f).apply { setOnClickListener { closeMenu(); openSys(Settings.ACTION_SETTINGS) } })
        panel.addView(foot, lp(MATCH_PARENT))
        root.addView(panel, FrameLayout.LayoutParams(panelW, (dm.heightPixels * 0.72).toInt(), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(60) })

        // barra de tarefas
        val bar = FrameLayout(this).apply { setBackgroundColor(BAR) }
        val center = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        center.addView(tbBtn(WinLogo()) { toggleMenu() })
        center.addView(tbBtn(tv("🔍", 18f)) { toggleMenu(true) })
        center.addView(tbBtn(ImageView(this).apply { setImageResource(R.drawable.ic_folder) }, 24) { toggleExplorer() })
        taskIcons = LinearLayout(this)
        center.addView(taskIcons)
        bar.addView(center, FrameLayout.LayoutParams(WRAP_CONTENT, MATCH_PARENT, Gravity.CENTER))
        val trayBox = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        trayBox.addView(tv("⌃  POR  📶  🔊  ", 11f))
        tray = tv("", 11f).apply { gravity = Gravity.END }
        trayBox.addView(tray)
        bar.addView(trayBox, FrameLayout.LayoutParams(WRAP_CONTENT, MATCH_PARENT, Gravity.END).apply { rightMargin = dp(10) })
        root.addView(bar, FrameLayout.LayoutParams(MATCH_PARENT, dp(56), Gravity.BOTTOM))

        setContentView(root)
        loadWallpaper()
        loadApps()
        if (reopen) { reopen = false; openSettings("personal") }
    }

    override fun onResume() {
        super.onResume(); closeMenu(); loadApps(); handler.post(ticker)
        if (ex.visibility == View.VISIBLE) refresh()
    }
    override fun onPause() { super.onPause(); handler.removeCallbacks(ticker) }
    override fun onBackPressed() {
        if (panel.visibility == View.VISIBLE) closeMenu()
        else if (stg.visibility == View.VISIBLE) hidePanel(stg)
        else if (ex.visibility == View.VISIBLE) hideExplorer()
    }
    override fun onKeyUp(k: Int, e: KeyEvent): Boolean {
        if (k == KeyEvent.KEYCODE_META_LEFT || k == KeyEvent.KEYCODE_META_RIGHT) { toggleMenu(); return true }
        return super.onKeyUp(k, e)
    }
    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r); refresh()
    }

    private fun deskIcon(e: String, n: String, click: () -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(8), dp(6), dp(8), dp(6))
        addView(tv(e, 30f))
        addView(tv(n, 11f, Color.WHITE).apply { setShadowLayer(6f, 0f, 1f, Color.BLACK) })
        setOnClickListener { click() }
        pressFx(this)
    }

    private fun tbBtn(v: View, sz: Int = 0, click: (View) -> Unit): View = FrameLayout(this).apply {
        val s = if (sz > 0) dp(sz) else WRAP_CONTENT
        addView(v, FrameLayout.LayoutParams(s, s, Gravity.CENTER))
        setPadding(dp(10), dp(8), dp(10), dp(8))
        setOnClickListener { click(it) }
        pressFx(this)
    }

    private fun cap(g: String, a: () -> Unit) = tv(g, 14f).apply { setPadding(dp(16), dp(8), dp(16), dp(8)); setOnClickListener { a() } }

    private fun openSys(action: String) {
        try { startActivity(Intent(action)) } catch (e: Exception) { Toast.makeText(this, "Não foi possível abrir", Toast.LENGTH_SHORT).show() }
    }

    // ---------- menu iniciar ----------
    private fun toggleMenu(focus: Boolean = false) {
        if (panel.visibility == View.VISIBLE && !focus) closeMenu()
        else { allView = false; search.setText(""); render(); showPanel(panel); if (focus) search.requestFocus() }
    }

    private fun closeMenu() {
        hidePanel(panel); search.setText("")
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(search.windowToken, 0)
    }

    private fun label(ri: ResolveInfo) = ri.loadLabel(packageManager).toString()

    private fun isGame(ri: ResolveInfo): Boolean {
        val pkg = ri.activityInfo.packageName
        if (prefs.contains("g_$pkg")) return prefs.getBoolean("g_$pkg", false)
        val ai = ri.activityInfo.applicationInfo
        if (Build.VERSION.SDK_INT >= 26 && ai.category == ApplicationInfo.CATEGORY_GAME) return true
        @Suppress("DEPRECATION")
        return (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
    }

    // abre o app com zoom saindo do ícone (estilo iOS)
    private fun launch(ri: ResolveInfo, from: View? = null) {
        closeMenu()
        val i = packageManager.getLaunchIntentForPackage(ri.activityInfo.packageName) ?: return
        val o = if (from != null) ActivityOptions.makeScaleUpAnimation(from, 0, 0, maxOf(from.width, 1), maxOf(from.height, 1)).toBundle() else null
        startActivity(i, o)
    }

    private fun loadApps() {
        val pm = packageManager
        apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .filter { it.activityInfo.packageName != packageName }.sortedBy { label(it).lowercase() }
        taskIcons.removeAllViews()
        apps.take(4).forEach { ri -> taskIcons.addView(tbBtn(iconView(ri), 26) { v -> launch(ri, v) }) }
    }

    private fun iconView(ri: ResolveInfo) = ImageView(this).apply { setImageDrawable(ri.loadIcon(packageManager)) }

    private fun bindApp(v: View, ri: ResolveInfo) {
        v.setOnClickListener { launch(ri, v) }
        v.setOnLongClickListener {
            val now = isGame(ri)
            prefs.edit().putBoolean("g_" + ri.activityInfo.packageName, !now).apply()
            Toast.makeText(this, if (now) "Movido para Apps" else "Movido para Jogos", Toast.LENGTH_SHORT).show()
            render(); true
        }
        pressFx(v)
    }

    private fun symCell(e: String, n: String, click: () -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(2), dp(8), dp(2), dp(8))
        addView(tv(e, 24f).apply { gravity = Gravity.CENTER }, lp(dp(32), dp(32)))
        addView(tv(n, 10f).apply { maxLines = 1; gravity = Gravity.CENTER; ellipsize = TextUtils.TruncateAt.END },
            lp(MATCH_PARENT).apply { topMargin = dp(4) })
        setOnClickListener { click() }
        pressFx(this)
    }

    private fun cell(ri: ResolveInfo) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(2), dp(8), dp(2), dp(8))
        addView(iconView(ri).apply { layoutParams = lp(dp(32), dp(32)) })
        addView(tv(label(ri), 10f).apply { maxLines = 1; gravity = Gravity.CENTER; ellipsize = TextUtils.TruncateAt.END },
            lp(MATCH_PARENT).apply { topMargin = dp(4) })
        bindApp(this, ri)
    }

    private fun row(ri: ResolveInfo) = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(8), dp(4), dp(8))
        addView(iconView(ri).apply { layoutParams = lp(dp(28), dp(28)) })
        addView(tv("   " + label(ri), 13f))
        bindApp(this, ri)
    }

    private fun recRow(ri: ResolveInfo) = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(8), dp(4), dp(8))
        addView(iconView(ri).apply { layoutParams = lp(dp(28), dp(28)) })
        val col = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        col.addView(tv(label(ri), 12f).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
        col.addView(tv("Adicionado recentemente", 9f, SUB).apply { maxLines = 1 })
        addView(col, lp(0, WRAP_CONTENT, 1f))
        bindApp(this, ri)
    }

    private fun head(t: String, a: String, click: () -> Unit) {
        val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        r.addView(tv(t, 14f, TXT, true), lp(0, WRAP_CONTENT, 1f))
        r.addView(tv(a, 11f).apply {
            background = round(FIELD, 5, BORDER); setPadding(dp(10), dp(4), dp(10), dp(4)); setOnClickListener { click() }
        })
        body.addView(r, lp(MATCH_PARENT).apply { topMargin = dp(12); bottomMargin = dp(8) })
    }

    private fun sub(t: String) = body.addView(tv(t, 12f, SUB, true).apply { setPadding(0, dp(8), 0, dp(4)) })

    private fun render() {
        body.removeAllViews()
        val q = search.text.toString().trim().lowercase()
        if (q.isNotEmpty()) { apps.filter { label(it).lowercase().contains(q) }.forEach { body.addView(row(it)) }; return }
        if (allView) {
            head("Todos os apps", "‹  Voltar") { allView = false; render() }
            val (g, a) = apps.partition { isGame(it) }
            sub("Apps"); a.forEach { body.addView(row(it)) }
            if (g.isNotEmpty()) { sub("Jogos"); g.forEach { body.addView(row(it)) } }
            return
        }
        head("Fixados", "Todos os apps  ›") { allView = true; render() }
        val grid = GridLayout(this).apply { columnCount = 6 }
        val w = (panelW - dp(32)) / 6
        grid.addView(symCell("⚙️", "Configurações") { openSettings("home") }, GridLayout.LayoutParams().apply { width = w; height = WRAP_CONTENT })
        apps.take(17).forEach { grid.addView(cell(it), GridLayout.LayoutParams().apply { width = w; height = WRAP_CONTENT }) }
        body.addView(grid)
        head("Recomendados", "Mais  ›") { allView = true; render() }
        val rec = apps.sortedByDescending {
            try { packageManager.getPackageInfo(it.activityInfo.packageName, 0).firstInstallTime } catch (e: Exception) { 0L }
        }.take(6)
        val rg = GridLayout(this).apply { columnCount = 2 }
        val rw = (panelW - dp(32)) / 2
        rec.forEach { rg.addView(recRow(it), GridLayout.LayoutParams().apply { width = rw; height = WRAP_CONTENT }) }
        body.addView(rg)
    }

    // ---------- Configurações ----------
    private class Tile(val e: String, val n: String, val d: String, val a: () -> Unit)

    private fun buildSettings(): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE; isClickable = true
            background = round(WINBG, 8, BORDER); elevation = dp(16).toFloat()
        }
        val title = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(TITLE); setPadding(dp(14), 0, 0, 0) }
        stgTitle = tv("Configurações", 12f)
        title.addView(stgTitle, lp(0, WRAP_CONTENT, 1f))
        title.addView(cap("—") { hidePanel(stg) }); title.addView(cap("✕") { hidePanel(stg) })
        box.addView(title)
        stgBody = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(16), dp(20), dp(20)) }
        box.addView(ScrollView(this).apply { addView(stgBody) }, lp(MATCH_PARENT, 0, 1f))
        return box
    }

    private fun openSettings(page: String) {
        closeMenu(); stgPage = page; renderSettings()
        if (stg.visibility != View.VISIBLE) showPanel(stg)
    }

    private fun tileView(t: Tile) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(6), dp(14), dp(6), dp(14))
        addView(tv(t.e, 30f))
        addView(tv(t.n, 12f, TXT, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(6), 0, dp(2)) })
        addView(tv(t.d, 9f, SUB).apply { gravity = Gravity.CENTER })
        background = pressBg(); setOnClickListener { t.a() }
        pressFx(this)
    }

    private fun renderSettings() {
        stgBody.removeAllViews()
        if (stgPage == "personal") { personalPage(); return }
        stgTitle.text = "Configurações"
        stgBody.addView(tv("Configurações do Windows", 20f).apply { gravity = Gravity.CENTER }, lp(MATCH_PARENT).apply { bottomMargin = dp(14) })
        val cols = if (settingsW > dp(560)) 4 else 2
        val tw = (settingsW - dp(40)) / cols
        val tiles = listOf(
            Tile("💻", "Sistema", "Tela, notificações, aplicativos, energia") { openSys(Settings.ACTION_DISPLAY_SETTINGS) },
            Tile("⌨️", "Dispositivos", "Bluetooth, impressoras, mouse") { openSys(Settings.ACTION_BLUETOOTH_SETTINGS) },
            Tile("🌐", "Rede e Internet", "Wi-Fi, modo avião, VPN") { openSys(Settings.ACTION_WIRELESS_SETTINGS) },
            Tile("🖌️", "Personalização", "Tela de Fundo, tema claro e escuro, cores") { stgPage = "personal"; renderSettings() },
            Tile("👤", "Contas", "Suas contas, email, sincronização, trabalho, família") { openSys(Settings.ACTION_SYNC_SETTINGS) },
            Tile("🕐", "Hora e idioma", "Fala, região, data") { openSys(Settings.ACTION_DATE_SETTINGS) },
            Tile("♿", "Facilidade de Acesso", "Narrador, lupa, alto contraste") { openSys(Settings.ACTION_ACCESSIBILITY_SETTINGS) },
            Tile("🔒", "Privacidade", "Localização, câmera") { openSys(Settings.ACTION_PRIVACY_SETTINGS) }
        )
        val grid = GridLayout(this).apply { columnCount = cols }
        fun fill(q: String) {
            grid.removeAllViews()
            tiles.filter { it.n.lowercase().contains(q) || it.d.lowercase().contains(q) }
                .forEach { grid.addView(tileView(it), GridLayout.LayoutParams().apply { width = tw; height = WRAP_CONTENT }) }
        }
        val sb = EditText(this).apply {
            hint = "🔍  Localizar uma configuração"; textSize = 13f; setSingleLine(); setTextColor(TXT); setHintTextColor(SUB)
            background = round(FIELD, 4, BLUE); setPadding(dp(12), dp(10), dp(12), dp(10))
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { fill(s.toString().trim().lowercase()) }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        stgBody.addView(sb, lp(MATCH_PARENT).apply { bottomMargin = dp(18) })
        stgBody.addView(grid)
        fill("")
    }

    private fun section(t: String) = stgBody.addView(tv(t, 13f, TXT, true), lp(MATCH_PARENT).apply { topMargin = dp(20); bottomMargin = dp(8) })

    private fun pill(t: String, sel: Boolean, click: () -> Unit) = tv(t, 12f, if (sel) Color.WHITE else TXT).apply {
        gravity = Gravity.CENTER; setPadding(dp(6), dp(12), dp(6), dp(12))
        background = round(if (sel) BLUE else FIELD, 8, BORDER); setOnClickListener { click() }
        pressFx(this)
    }

    private fun pills(vararg ps: View) {
        val r = LinearLayout(this)
        ps.forEachIndexed { i, p -> r.addView(p, lp(0, WRAP_CONTENT, 1f).apply { if (i < ps.size - 1) rightMargin = dp(8) }) }
        stgBody.addView(r, lp(MATCH_PARENT))
    }

    private fun personalPage() {
        stgTitle.text = "Configurações › Personalização"
        stgBody.addView(tv("←  Voltar", 12f, BLUE).apply { setPadding(0, 0, 0, dp(10)); setOnClickListener { stgPage = "home"; renderSettings() } })
        stgBody.addView(tv("Personalização", 20f, TXT, true))
        section("Tema")
        pills(pill("☀️  Claro", !dark) { setTheme(false) }, pill("🌙  Escuro", dark) { setTheme(true) })
        section("Plano de fundo")
        pills(pill("🖼️  Escolher da galeria", false) { pickWallpaper() }, pill("↺  Restaurar padrão", false) { resetWallpaper() })
        section("Ajuste (ver o wallpaper todo)")
        pills(pill("Ajustar", fit == 1) { setFit(1) }, pill("Preencher", fit == 0) { setFit(0) }, pill("Esticar", fit == 2) { setFit(2) })
        stgBody.addView(tv("Ajustar mostra a imagem inteira, sem cortar.", 10f, SUB).apply { setPadding(0, dp(8), 0, 0) })
    }

    private fun setTheme(d: Boolean) {
        if (d == dark) return
        dark = d; prefs.edit().putBoolean("dark", d).apply()
        reopen = true; buildUI()
    }

    private fun setFit(m: Int) { fit = m; prefs.edit().putInt("fit", m).apply(); applyFit(); renderSettings() }

    private fun resetWallpaper() {
        File(filesDir, "wp.img").delete()
        bg.setImageBitmap(bloom(resources.displayMetrics.widthPixels, resources.displayMetrics.heightPixels))
        rootV.setBackgroundColor(Color.parseColor("#9FC3E8")); applyFit()
    }

    private fun applyFit() {
        val custom = File(filesDir, "wp.img").exists()
        bg.scaleType = if (!custom) ImageView.ScaleType.CENTER_CROP else when (fit) {
            0 -> ImageView.ScaleType.CENTER_CROP
            1 -> ImageView.ScaleType.FIT_CENTER
            else -> ImageView.ScaleType.FIT_XY
        }
        (bg.layoutParams as FrameLayout.LayoutParams).bottomMargin = if (custom && fit == 1) dp(56) else 0
        bg.requestLayout()
    }

    // ---------- Explorador de Arquivos ----------
    @Suppress("DEPRECATION")
    private fun pub(d: String): File = Environment.getExternalStoragePublicDirectory(d)

    private fun buildExplorer(): LinearLayout {
        val wide = explorerW > dp(560)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE; isClickable = true
            background = round(WINBG, 8, BORDER); elevation = dp(16).toFloat()
        }
        val title = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(TITLE); setPadding(dp(8), dp(6), 0, 0) }
        exTitle = tv("", 12f).apply {
            background = round(WINBG, 6); setPadding(dp(12), dp(8), dp(12), dp(8))
            val d = resources.getDrawable(R.drawable.ic_folder, theme); d.setBounds(0, 0, dp(16), dp(16))
            setCompoundDrawables(d, null, null, null); compoundDrawablePadding = dp(8)
        }
        title.addView(exTitle)
        title.addView(View(this), lp(0, 1, 1f))
        title.addView(cap("—") { hideExplorer() }); title.addView(cap("▢") { toggleMax() }); title.addView(cap("✕") { hideExplorer() })
        box.addView(title)

        fun tool(t: String, a: () -> Unit) = tv(t, 12f).apply { setPadding(dp(10), dp(8), dp(10), dp(8)); setOnClickListener { a() } }
        val tb = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(2), dp(8), dp(2)) }
        tb.addView(tool("➕ Novo") { newFolder() })
        for (g in listOf("✂", "📋", "✏", "🗑")) tb.addView(tool(g) { Toast.makeText(this, "Em breve", Toast.LENGTH_SHORT).show() })
        tb.addView(tool("⇅ Classificar") { byDate = !byDate; refresh(true) })
        tb.addView(tool("☰ Exibir") { Toast.makeText(this, "Em breve", Toast.LENGTH_SHORT).show() })
        box.addView(HorizontalScrollView(this).apply { addView(tb) })

        val ar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(6), dp(2), dp(8), dp(6)) }
        ar.addView(tool("←") { back() }); ar.addView(tool("→") { }); ar.addView(tool("↑") { up() }); ar.addView(tool("⟳") { refresh(true) })
        exAddr = tv("", 11f).apply {
            maxLines = 1; ellipsize = TextUtils.TruncateAt.START
            background = round(FIELD, 6, BORDER); setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        ar.addView(exAddr, lp(0, WRAP_CONTENT, 1f).apply { setMargins(dp(4), 0, dp(6), 0) })
        exSearch = EditText(this).apply {
            hint = "🔍 Pesquisar"; textSize = 11f; setSingleLine(); setTextColor(TXT); setHintTextColor(SUB)
            background = round(FIELD, 6, BORDER); setPadding(dp(10), dp(8), dp(10), dp(8))
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { refresh() }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        ar.addView(exSearch, lp(dp(110)))
        box.addView(ar)

        val nav = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(6), dp(4), dp(6), dp(4)) }
        fun navItem(e: String, n: String, f: File) = nav.addView(tv("$e  $n", 12f).apply {
            maxLines = 1; setPadding(dp(8), dp(8), dp(8), dp(8)); setOnClickListener { go(f) }
        })
        navItem("🏠", "Início", sd); navItem("🖼️", "Galeria", pub(Environment.DIRECTORY_PICTURES))
        navItem("🖥️", "Área de Trabalho", File(sd, "Desktop").takeIf { it.exists() } ?: sd)
        navItem("⬇️", "Downloads", pub(Environment.DIRECTORY_DOWNLOADS))
        navItem("📄", "Documentos", pub(Environment.DIRECTORY_DOCUMENTS))
        navItem("🏞️", "Imagens", pub(Environment.DIRECTORY_PICTURES))
        navItem("🎵", "Músicas", pub(Environment.DIRECTORY_MUSIC))
        navItem("🎬", "Vídeos", pub(Environment.DIRECTORY_MOVIES))
        nav.addView(tv("Este Computador", 11f, SUB, true).apply { setPadding(dp(8), dp(12), 0, dp(4)) })
        navItem("💽", "Armazenamento", sd)
        val main = LinearLayout(this)
        main.addView(ScrollView(this).apply { addView(nav) }, lp(dp(if (wide) 170 else 112), MATCH_PARENT))
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(CONTENT) }
        content.addView(colRow(wide, null, "Nome", "Data de modificação", "Tipo", "Tamanho"))
        exList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(ScrollView(this).apply { addView(exList) }, lp(MATCH_PARENT, 0, 1f))
        main.addView(content, lp(0, MATCH_PARENT, 1f))
        box.addView(main, lp(MATCH_PARENT, 0, 1f))
        exStatus = tv("", 11f, SUB).apply { setPadding(dp(14), dp(6), dp(14), dp(6)) }
        box.addView(exStatus)
        return box
    }

    private fun folderIcon() = ImageView(this).apply { setImageResource(R.drawable.ic_folder) }

    private fun colRow(wide: Boolean, ico: View?, n: String, d: String, t: String, s: String): LinearLayout {
        val gray = SUB
        return LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(7), dp(8), dp(7))
            addView(ico ?: tv("", 16f), if (ico is ImageView) lp(dp(24), dp(24)).apply { rightMargin = dp(4) } else lp(dp(28)))
            addView(tv(n, 12f, if (ico == null) gray else TXT).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }, lp(0, WRAP_CONTENT, 1f))
            addView(tv(d, 11f, gray).apply { maxLines = 1 }, lp(dp(if (wide) 130 else 78)))
            if (wide) addView(tv(t, 11f, gray).apply { maxLines = 1 }, lp(dp(120)))
            addView(tv(s, 11f, gray).apply { maxLines = 1; gravity = Gravity.END }, lp(dp(64)))
        }
    }

    private fun emoji(f: File) = when (f.extension.lowercase()) {
        "jpg", "jpeg", "png", "gif", "webp" -> "🖼️"
        "mp4", "mkv", "avi", "mov" -> "🎬"
        "mp3", "wav", "ogg", "m4a" -> "🎵"
        "apk" -> "🤖"
        "zip", "rar", "7z" -> "🗜️"
        "pdf" -> "📕"
        else -> "📄"
    }

    private fun fileRow(f: File): View {
        val wide = explorerW > dp(560)
        val ext = f.extension
        val date = (if (wide) dfWide else dfNarrow).format(Date(f.lastModified()))
        val type = if (f.isDirectory) "Pasta de arquivos" else if (ext.isEmpty()) "Arquivo" else "Arquivo " + ext.uppercase()
        val size = if (f.isDirectory) "" else "%,d KB".format((f.length() + 1023) / 1024)
        return colRow(wide, if (f.isDirectory) folderIcon() else tv(emoji(f), 16f), f.name, date, type, size).apply {
            background = pressBg()
            setOnClickListener { if (f.isDirectory) go(f) else openFile(f) }
        }
    }

    private fun hasAccess(): Boolean = if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun askAccess() {
        if (Build.VERSION.SDK_INT >= 30)
            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
        else requestPermissions(arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE, android.Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
    }

    private fun refresh(anim: Boolean = false) {
        exList.removeAllViews()
        if (anim) {
            exList.alpha = 0f; exList.translationY = dp(10).toFloat()
            exList.animate().alpha(1f).translationY(0f).setDuration(260).setInterpolator(Spring()).start()
        }
        exTitle.text = if (cur == sd) "Armazenamento" else cur.name
        exAddr.text = "💻 › Armazenamento interno" + cur.path.removePrefix(sd.path).split("/").filter { it.isNotEmpty() }.joinToString("") { " › $it" }
        if (!hasAccess()) {
            exList.addView(tv("Para ver seus arquivos, permita o acesso ao armazenamento.", 12f, SUB).apply { setPadding(dp(16), dp(24), dp(16), dp(8)) })
            exList.addView(tv("Permitir acesso", 13f, Color.WHITE).apply {
                background = round(BLUE, 6); setPadding(dp(16), dp(10), dp(16), dp(10)); setOnClickListener { askAccess() }
            }, lp(WRAP_CONTENT).apply { setMargins(dp(16), 0, 0, 0) })
            exStatus.text = ""; return
        }
        val q = exSearch.text.toString().trim().lowercase()
        val list = (cur.listFiles() ?: emptyArray()).filter { !it.name.startsWith(".") && (q.isEmpty() || it.name.lowercase().contains(q)) }
            .let { l -> if (byDate) l.sortedWith(compareBy<File>({ !it.isDirectory }, { -it.lastModified() }))
                        else l.sortedWith(compareBy<File>({ !it.isDirectory }, { it.name.lowercase() })) }
        list.forEach { exList.addView(fileRow(it)) }
        exStatus.text = "${list.size} itens"
    }

    private fun go(f: File) { hist.add(cur); cur = f; exSearch.setText(""); refresh(true) }
    private fun back() { if (hist.isNotEmpty()) { cur = hist.removeAt(hist.size - 1); refresh(true) } }
    private fun up() { if (cur != sd) cur.parentFile?.let { go(it) } }

    private fun newFolder() {
        var n = File(cur, "Nova pasta"); var i = 2
        while (n.exists()) { n = File(cur, "Nova pasta ($i)"); i++ }
        n.mkdir(); refresh()
    }

    private fun openFile(f: File) {
        try {
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
            val uri = FileProvider.getUriForFile(this, "$packageName.fp", f)
            startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (e: Exception) { Toast.makeText(this, "Nenhum app para abrir este arquivo", Toast.LENGTH_SHORT).show() }
    }

    private fun toggleExplorer() {
        if (ex.visibility == View.VISIBLE) hideExplorer()
        else { closeMenu(); if (!hasAccess()) askAccess(); refresh(true); showPanel(ex) }
    }

    private fun hideExplorer() { hidePanel(ex) }

    private fun toggleMax() {
        exMax = !exMax
        val dm = resources.displayMetrics
        val l = ex.layoutParams as FrameLayout.LayoutParams
        val h0 = l.height; val t0 = l.topMargin; val w0 = l.width
        val h1 = if (exMax) dm.heightPixels - dp(56) - dp(30) else (dm.heightPixels * 0.76).toInt()
        val t1 = if (exMax) dp(24) else dp(36)
        val w1 = if (exMax) dm.widthPixels else explorerW
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 420; interpolator = Spring()
            addUpdateListener { a ->
                val f = a.animatedValue as Float
                l.height = (h0 + (h1 - h0) * f).toInt(); l.topMargin = (t0 + (t1 - t0) * f).toInt()
                l.width = (w0 + (w1 - w0) * f).toInt(); ex.requestLayout()
            }
            start()
        }
    }

    // ---------- wallpaper ----------
    private fun pickWallpaper() {
        startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), PICK)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == PICK && res == RESULT_OK && data?.data != null) {
            contentResolver.openInputStream(data.data!!)?.use { input ->
                File(filesDir, "wp.img").outputStream().use { input.copyTo(it) }
            }
            loadWallpaper()
        }
    }

    private fun loadWallpaper() {
        val f = File(filesDir, "wp.img")
        if (f.exists()) {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.path, o)
            val s = maxOf(1, maxOf(o.outWidth, o.outHeight) / 1800)
            val bmp = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
            if (bmp != null) { bg.setImageBitmap(bmp); rootV.setBackgroundColor(bmp.getPixel(0, 0)) }
        }
        applyFit()
    }
}
