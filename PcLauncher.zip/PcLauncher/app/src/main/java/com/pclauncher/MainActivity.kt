package com.pclauncher

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.content.pm.ApplicationInfo
import android.content.pm.ResolveInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var bg: ImageView
    private lateinit var bigClock: TextView
    private lateinit var bigDate: TextView
    private lateinit var trayClock: TextView
    private lateinit var grid: GridLayout
    private lateinit var menu: LinearLayout
    private val handler = Handler(Looper.getMainLooper())
    private val PICK = 42

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private val ticker = object : Runnable {
        override fun run() {
            val now = Date()
            val h = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
            bigClock.text = h
            trayClock.text = h + "\n" + SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(now)
            bigDate.text = SimpleDateFormat("EEEE, d 'de' MMMM", Locale.getDefault()).format(now)
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.parseColor("#1b2a41"))

        bg = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        root.addView(bg, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        root.setOnLongClickListener { pickWallpaper(); true }

        // relógio grande
        val clockBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.END }
        bigClock = text(46f, true)
        bigDate = text(14f, false)
        clockBox.addView(bigClock); clockBox.addView(bigDate)
        root.addView(clockBox, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.TOP or Gravity.END).apply {
            setMargins(0, dp(48), dp(16), 0)
        })

        // ícones dos apps
        val scroll = ScrollView(this)
        grid = GridLayout(this).apply { columnCount = 4 }
        scroll.addView(grid)
        root.addView(scroll, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT).apply {
            setMargins(dp(8), dp(120), dp(8), dp(64))
        })

        // menu iniciar
        menu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            background = GradientDrawable().apply { setColor(Color.parseColor("#E6141622")); cornerRadius = dp(14).toFloat() }
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        menu.addView(menuItem("🖼️  Trocar wallpaper") { menu.visibility = View.GONE; pickWallpaper() })
        menu.addView(menuItem("⚙️  Configurações") { menu.visibility = View.GONE; startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) })
        menu.addView(menuItem("📱  Launcher padrão") { menu.visibility = View.GONE; startActivity(Intent(android.provider.Settings.ACTION_HOME_SETTINGS)) })
        root.addView(menu, FrameLayout.LayoutParams(dp(220), WRAP_CONTENT, Gravity.BOTTOM or Gravity.START).apply {
            setMargins(dp(8), 0, 0, dp(64))
        })

        // barra de tarefas
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#B8141622")); setPadding(dp(10), 0, dp(12), 0)
        }
        val start = TextView(this).apply {
            this.text = "⊞"; textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = GradientDrawable().apply { setColor(Color.parseColor("#4f8cff")); cornerRadius = dp(10).toFloat() }
            setOnClickListener { menu.visibility = if (menu.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
        }
        bar.addView(start, LinearLayout.LayoutParams(dp(42), dp(42)))
        bar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        trayClock = text(12f, false).apply { gravity = Gravity.END; setShadowLayer(0f, 0f, 0f, 0) }
        bar.addView(trayClock)
        root.addView(bar, FrameLayout.LayoutParams(MATCH_PARENT, dp(56), Gravity.BOTTOM))

        setContentView(root)
        loadWallpaper()
    }

    override fun onResume() {
        super.onResume()
        menu.visibility = View.GONE
        loadApps()
        handler.post(ticker)
    }

    override fun onPause() { super.onPause(); handler.removeCallbacks(ticker) }

    override fun onBackPressed() { /* launcher não fecha */ }

    private fun text(size: Float, light: Boolean) = TextView(this).apply {
        textSize = size; setTextColor(Color.WHITE)
        if (light) typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        setShadowLayer(8f, 0f, 2f, Color.BLACK)
    }

    private fun menuItem(label: String, click: () -> Unit) = TextView(this).apply {
        this.text = label; textSize = 15f; setTextColor(Color.WHITE); setPadding(dp(12), dp(12), dp(12), dp(12))
        setOnClickListener { click() }
    }

    private fun isGame(ri: ResolveInfo): Boolean {
        val pkg = ri.activityInfo.packageName
        val prefs = getSharedPreferences("p", MODE_PRIVATE)
        if (prefs.contains("g_$pkg")) return prefs.getBoolean("g_$pkg", false)
        val ai = ri.activityInfo.applicationInfo
        if (Build.VERSION.SDK_INT >= 26 && ai.category == ApplicationInfo.CATEGORY_GAME) return true
        @Suppress("DEPRECATION")
        return (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
    }

    private fun header(title: String) {
        val t = text(15f, false).apply {
            this.text = title; setTypeface(typeface, Typeface.BOLD); setPadding(dp(8), dp(14), 0, dp(4))
        }
        grid.addView(t, GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(0, 4)).apply { width = MATCH_PARENT })
    }

    private fun addSection(title: String, list: List<ResolveInfo>) {
        if (list.isEmpty()) return
        header(title)
        val pm = packageManager
        val w = resources.displayMetrics.widthPixels / 4 - dp(4)
        for (ri in list) {
            val pkg = ri.activityInfo.packageName
            val cell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(2), dp(8), dp(2), dp(8)) }
            cell.addView(ImageView(this).apply { setImageDrawable(ri.loadIcon(pm)) }, LinearLayout.LayoutParams(dp(52), dp(52)))
            cell.addView(text(11f, false).apply {
                this.text = ri.loadLabel(pm); gravity = Gravity.CENTER; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
            }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(4) })
            cell.setOnClickListener { pm.getLaunchIntentForPackage(pkg)?.let { startActivity(it) } }
            // segurar = mover entre Apps e Jogos
            cell.setOnLongClickListener {
                val now = isGame(ri)
                getSharedPreferences("p", MODE_PRIVATE).edit().putBoolean("g_$pkg", !now).apply()
                Toast.makeText(this, if (now) "Movido para Apps" else "Movido para Jogos", Toast.LENGTH_SHORT).show()
                loadApps(); true
            }
            grid.addView(cell, GridLayout.LayoutParams().apply { width = w; height = WRAP_CONTENT })
        }
    }

    private fun loadApps() {
        grid.removeAllViews()
        val pm = packageManager
        val all = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
        val (games, apps) = all.partition { isGame(it) }
        addSection("📱  Apps", apps)
        addSection("🎮  Jogos", games)
    }

    private fun pickWallpaper() {
        startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), PICK)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == PICK && res == RESULT_OK && data?.data != null) {
            contentResolver.openInputStream(data.data!!)?.use { input ->
                File(filesDir, "wp.img").outputStream().use { input.copyTo(it) }
            }
            loadWallpaper()
        }
    }

    private fun loadWallpaper() {
        val f = File(filesDir, "wp.img")
        if (!f.exists()) return
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        val s = maxOf(1, maxOf(o.outWidth, o.outHeight) / 1800)
        bg.setImageBitmap(BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s }))
    }
}
